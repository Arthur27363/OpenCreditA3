package view;

import model.Cliente;
import service.ClienteService;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

// Classe principal responsável pela interação com o usuário via console
public class Main {
    // Instância do serviço que contém a lógica de negócio relacionada ao Cliente
    private static ClienteService service = new ClienteService();
    // Scanner para leitura de dados do teclado
    private static Scanner scanner = new Scanner(System.in);

    // Método principal - ponto de entrada do programa
    public static void main(String[] args) {
        int opcao; // variável para armazenar a opção escolhida pelo usuário

        do {
            // Exibe o menu de opções para o usuário
            System.out.println("\n--- MENU CLIENTES ---");
            System.out.println("1. Cadastrar Cliente");
            System.out.println("2. Listar Clientes");
            System.out.println("3. Atualizar Cliente");
            System.out.println("4. Remover Cliente");
            System.out.println("5. Pesquisar Cliente");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            // Lê a opção do usuário, converte para inteiro
            opcao = Integer.parseInt(scanner.nextLine());

            // Executa a ação conforme a opção escolhida
            switch (opcao) {
                case 1 -> cadastrarCliente();    // chama método para cadastrar cliente
                case 2 -> listarClientes();      // chama método para listar clientes
                case 3 -> atualizarCliente();    // chama método para atualizar cliente
                case 4 -> removerCliente();      // chama método para remover cliente
                case 5 -> pesquisarCliente();    // chama método para pesquisar cliente
                case 0 -> System.out.println("Encerrando..."); // mensagem de saída
                default -> System.out.println("Opção inválida."); // caso a opção não seja válida
            }
        } while (opcao != 0); // o laço continua até o usuário digitar 0 para sair
    }

    // Método para cadastrar um novo cliente
    private static void cadastrarCliente() {
        try {
            // Solicita e lê os dados do cliente
            System.out.print("CPF: ");
            String cpf = scanner.nextLine();

            System.out.print("ID Interno: ");
            int id = Integer.parseInt(scanner.nextLine());

            System.out.print("Nome Completo: ");
            String nome = scanner.nextLine();

            System.out.print("Valor da Dívida: ");
            double divida = Double.parseDouble(scanner.nextLine());

            System.out.print("Nível de Interação: ");
            String nivel = scanner.nextLine();

            // Cria um objeto Cliente com os dados fornecidos
            Cliente cliente = new Cliente(cpf, id, nome, divida, nivel);

            // Tenta cadastrar o cliente usando o serviço
            boolean cadastrado = service.cadastrarCliente(cliente);

            // Mensagem de sucesso ou de CPF duplicado
            System.out.println(cadastrado ? "Cliente cadastrado com sucesso!" : "CPF já existe.");
        } catch (Exception e) {
            // Caso haja algum erro na entrada ou no cadastro, exibe a mensagem
            System.out.println("Erro ao cadastrar cliente: " + e.getMessage());
        }
    }

    // Método para listar clientes com filtros opcionais
    private static void listarClientes() {
        try {
            System.out.println("Bem-vindo a função visualizar clientes!");
            System.out.println("===================================");
            System.out.println("");
            System.out.println("Selecione filtros para pesquisa avançada.");
            System.out.println("");

            // Pergunta ao usuário sobre a situação da dívida (com dívida, sem dívida ou sem filtro)
            System.out.println("FILTRO POR DIVIDA");
            System.out.print("Digite (com_divida) ou (sem_divida) ou (Apenas Enter) para sem filtro): ");
            String situacao = scanner.nextLine();
            if (situacao.isBlank()) situacao = null; // se vazio, considera sem filtro

            // Pergunta sobre o nível de interação (ou sem filtro)
            System.out.print("Nível de interação (ou Enter): ");
            String nivel = scanner.nextLine();
            if (nivel.isBlank()) nivel = null;

            // Pergunta valor mínimo da dívida para filtro (ou sem filtro)
            System.out.println("FILTRO POR VALOR MÍNIMO");
            System.out.print("Digite um valor mínimo da dívida (ou Enter para sem filtro): ");
            String vMinStr = scanner.nextLine();
            Double vMin = vMinStr.isBlank() ? null : Double.parseDouble(vMinStr);

            // Pergunta valor máximo da dívida para filtro (ou sem filtro)
            System.out.println("FILTRO POR VALOR MÁXIMO");
            System.out.print("Digite um valor máximo da dívida (ou Enter para sem filtro): ");
            String vMaxStr = scanner.nextLine();
            Double vMax = vMaxStr.isBlank() ? null : Double.parseDouble(vMaxStr);

            // Solicita a lista de clientes ao serviço com os filtros aplicados
            List<Cliente> clientes = service.listarClientes(situacao, nivel, vMin, vMax);

            // Exibe a lista ou mensagem caso não haja resultados
            if (clientes.isEmpty()) {
                System.out.println("Nenhum cliente encontrado.");
            } else {
                clientes.forEach(System.out::println); // imprime cada cliente usando toString()
            }
        } catch (Exception e) {
            System.out.println("Erro ao listar clientes: " + e.getMessage());
        }
    }

    // Método para atualizar os dados de um cliente já cadastrado
    private static void atualizarCliente() {
        try {
            // Lê o CPF do cliente que será atualizado
            System.out.print("CPF do cliente a atualizar: ");
            String cpf = scanner.nextLine();

            // Lê os novos dados do cliente
            System.out.print("Novo nome completo: ");
            String nome = scanner.nextLine();

            System.out.print("Novo valor da dívida: ");
            double divida = Double.parseDouble(scanner.nextLine());

            System.out.print("Novo nível de interação: ");
            String nivel = scanner.nextLine();

            // Cria um objeto Cliente com os dados novos. O idInterno é definido como 0, pois não será alterado
            Cliente cliente = new Cliente(cpf, 0, nome, divida, nivel);

            // Tenta atualizar o cliente usando o serviço
            boolean atualizado = service.atualizarCliente(cliente);

            // Mensagem de sucesso ou falha
            System.out.println(atualizado ? "Cliente atualizado com sucesso!" : "Cliente não encontrado.");
        } catch (Exception e) {
            System.out.println("Erro ao atualizar cliente: " + e.getMessage());
        }
    }

    // Método para remover um cliente cadastrado pelo CPF
    private static void removerCliente() {
        try {
            // Lê o CPF do cliente a ser removido
            System.out.print("CPF do cliente a remover: ");
            String cpf = scanner.nextLine();

            // Tenta remover o cliente pelo serviço
            boolean removido = service.removerCliente(cpf);

            // Mensagem de sucesso ou falha
            System.out.println(removido ? "Cliente removido com sucesso!" : "Cliente não encontrado.");
        } catch (Exception e) {
            System.out.println("Erro ao remover cliente: " + e.getMessage());
        }
    }

    // Método para pesquisar clientes pelo CPF ou nome
    private static void pesquisarCliente() {
        try {
            // Lê o termo da pesquisa (CPF ou nome)
            System.out.print("Termo de busca (CPF ou nome): ");
            String termo = scanner.nextLine();

            // Busca clientes que correspondem ao termo usando o serviço
            List<Cliente> resultados = service.pesquisarClientes(termo);

            // Exibe os resultados ou mensagem caso nenhum seja encontrado
            if (resultados.isEmpty()) {
                System.out.println("Nenhum cliente encontrado.");
            } else {
                resultados.forEach(System.out::println);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao pesquisar cliente: " + e.getMessage());
        }
    }
}
