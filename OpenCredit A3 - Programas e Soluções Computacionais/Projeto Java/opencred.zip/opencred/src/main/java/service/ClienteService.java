package service;

import model.Cliente;
import dao.ClienteDAO;
import java.sql.SQLException;
import java.util.List;

// Classe de serviço que atua como intermediária entre a camada de apresentação (view) e a camada de dados (DAO)
public class ClienteService {
    // Instância do DAO para realizar operações no banco de dados
    private ClienteDAO dao = new ClienteDAO();

    // Método para cadastrar um cliente, delega a operação para o DAO
    // Retorna true se o cadastro foi realizado com sucesso, false caso contrário
    // Lança SQLException em caso de erro na comunicação com o banco
    public boolean cadastrarCliente(Cliente c) throws SQLException {
        return dao.inserirCliente(c);
    }

    // Método para listar clientes com base em filtros opcionais:
    // situacaoDivida (ex: "com_divida", "sem_divida" ou null),
    // nivelInteracao (ex: "alto", "baixo" ou null),
    // valorMin e valorMax para filtrar o valor da dívida
    // Retorna uma lista de clientes que atendem aos critérios
    public List<Cliente> listarClientes(String situacaoDivida, String nivelInteracao, Double valorMin, Double valorMax) throws SQLException {
        return dao.listarClientes(situacaoDivida, nivelInteracao, valorMin, valorMax);
    }

    // Método para atualizar os dados de um cliente existente
    // Retorna true se a atualização foi bem-sucedida, false se o cliente não foi encontrado
    public boolean atualizarCliente(Cliente c) throws SQLException {
        return dao.atualizarCliente(c);
    }

    // Método para remover um cliente pelo CPF
    // Retorna true se a remoção foi bem-sucedida, false se o cliente não foi encontrado
    public boolean removerCliente(String cpf) throws SQLException {
        return dao.removerCliente(cpf);
    }

    // Método para pesquisar clientes por um termo que pode ser CPF ou parte do nome
    // Retorna uma lista de clientes que correspondem ao termo pesquisado
    public List<Cliente> pesquisarClientes(String termo) throws SQLException {
        return dao.pesquisarClientes(termo);
    }
}
