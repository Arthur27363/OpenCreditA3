package model;

// Classe que representa um Cliente no sistema
public class Cliente {
    // Atributos privados que guardam os dados do cliente
    private String cpf;            // CPF do cliente, usado como identificador único
    private int idInterno;         // Um identificador interno numérico para o cliente
    private String nomeCompleto;   // Nome completo do cliente
    private double valorDivida;    // Valor da dívida do cliente
    private String nivelInteracao; // Nível de interação do cliente (ex: "alto", "médio", "baixo")

    // Construtor da classe que inicializa todos os atributos na criação do objeto Cliente
    public Cliente(String cpf, int idInterno, String nomeCompleto, double valorDivida, String nivelInteracao) {
        this.cpf = cpf;
        this.idInterno = idInterno;
        this.nomeCompleto = nomeCompleto;
        this.valorDivida = valorDivida;
        this.nivelInteracao = nivelInteracao;
    }

    // Métodos getters e setters para acessar e modificar os atributos privados

    // Retorna o CPF do cliente
    public String getCpf() { 
        return cpf; 
    }

    // Define um novo CPF para o cliente
    public void setCpf(String cpf) { 
        this.cpf = cpf; 
    }

    // Retorna o ID interno do cliente
    public int getIdInterno() { 
        return idInterno; 
    }

    // Define um novo ID interno para o cliente
    public void setIdInterno(int idInterno) { 
        this.idInterno = idInterno; 
    }

    // Retorna o nome completo do cliente
    public String getNomeCompleto() { 
        return nomeCompleto; 
    }

    // Define um novo nome completo para o cliente
    public void setNomeCompleto(String nomeCompleto) { 
        this.nomeCompleto = nomeCompleto; 
    }

    // Retorna o valor da dívida do cliente
    public double getValorDivida() { 
        return valorDivida; 
    }

    // Define um novo valor de dívida para o cliente
    public void setValorDivida(double valorDivida) { 
        this.valorDivida = valorDivida; 
    }

    // Retorna o nível de interação do cliente
    public String getNivelInteracao() { 
        return nivelInteracao; 
    }

    // Define um novo nível de interação para o cliente
    public void setNivelInteracao(String nivelInteracao) { 
        this.nivelInteracao = nivelInteracao; 
    }

    /**
     * Método sobrescrito da classe Object que retorna uma String
     * representando os dados do cliente formatados para facilitar a visualização.
     */
    @Override
    public String toString() {
        return "Cliente [CPF=" + cpf + ", ID Interno=" + idInterno + ", Nome=" + nomeCompleto + 
               ", Dívida=" + valorDivida + ", Nível Interação=" + nivelInteracao + "]";
    }
}
