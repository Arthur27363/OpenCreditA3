package dao;

import model.Cliente;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
    // Dados para conexão com o banco MySQL
    private final String url = "jdbc:mysql://localhost:3306/opencred";
    private final String user = "root";
    private final String password = "Marco@2006";

    // Método privado para obter uma conexão com o banco de dados
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    /**
     * Método para inserir um novo cliente no banco.
     * Verifica antes se o CPF já existe para evitar duplicidade.
     * Retorna true se inseriu, false se o CPF já existe.
     */
    public boolean inserirCliente(Cliente c) throws SQLException {
        if (existeCPF(c.getCpf())) { // Verifica se CPF já existe
            return false;
        }
        // Comando SQL para inserção dos dados na tabela clientes
        String sql = "INSERT INTO clientes (cpf, id_interno, nome_completo, valor_divida, nivel_interacao) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            // Configura os parâmetros da query com os dados do cliente
            ps.setString(1, c.getCpf());
            ps.setInt(2, c.getIdInterno());
            ps.setString(3, c.getNomeCompleto());
            ps.setDouble(4, c.getValorDivida());
            ps.setString(5, c.getNivelInteracao());
            ps.executeUpdate(); // Executa a inserção
            return true; // Sucesso
        }
    }

    /**
     * Verifica se um CPF já está cadastrado no banco.
     * Retorna true se CPF existe, false caso contrário.
     */
    public boolean existeCPF(String cpf) throws SQLException {
        String sql = "SELECT COUNT(*) FROM clientes WHERE cpf = ?";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, cpf); // Define o CPF no parâmetro
            ResultSet rs = ps.executeQuery();
            // Verifica se o resultado existe e se a contagem é maior que zero
            return rs.next() && rs.getInt(1) > 0;
        }
    }

    /**
     * Lista clientes filtrando por:
     * - situação da dívida (com ou sem dívida)
     * - nível de interação
     * - valor mínimo da dívida
     * - valor máximo da dívida
     * Retorna uma lista de clientes que atendem aos filtros.
     */
    public List<Cliente> listarClientes(String situacaoDivida, String nivelInteracao, Double valorMin, Double valorMax) throws SQLException {
        StringBuilder sql = new StringBuilder("SELECT * FROM clientes WHERE 1=1 ");
        
        // Monta os filtros de acordo com os parâmetros recebidos
        if (situacaoDivida != null) {
            if (situacaoDivida.equalsIgnoreCase("com_divida")) {
                sql.append("AND valor_divida > 0 ");
            } else if (situacaoDivida.equalsIgnoreCase("sem_divida")) {
                sql.append("AND valor_divida = 0 ");
            }
        }
        if (nivelInteracao != null) {
            sql.append("AND nivel_interacao = ? ");
        }
        if (valorMin != null) {
            sql.append("AND valor_divida >= ? ");
        }
        if (valorMax != null) {
            sql.append("AND valor_divida <= ? ");
        }

        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql.toString())) {
            int paramIndex = 1;
            // Seta os parâmetros do PreparedStatement conforme os filtros aplicados
            if (nivelInteracao != null) ps.setString(paramIndex++, nivelInteracao);
            if (valorMin != null) ps.setDouble(paramIndex++, valorMin);
            if (valorMax != null) ps.setDouble(paramIndex++, valorMax);

            ResultSet rs = ps.executeQuery();
            List<Cliente> clientes = new ArrayList<>();
            // Constrói a lista de clientes a partir do resultado da consulta
            while (rs.next()) {
                clientes.add(new Cliente(
                    rs.getString("cpf"),
                    rs.getInt("id_interno"),
                    rs.getString("nome_completo"),
                    rs.getDouble("valor_divida"),
                    rs.getString("nivel_interacao")
                ));
            }
            return clientes;
        }
    }

    /**
     * Atualiza os dados de um cliente existente no banco,
     * buscando pelo CPF para identificar o registro.
     * Retorna true se a atualização foi feita com sucesso.
     */
    public boolean atualizarCliente(Cliente c) throws SQLException {
        String sql = "UPDATE clientes SET nome_completo=?, valor_divida=?, nivel_interacao=? WHERE cpf=?";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getNomeCompleto());
            ps.setDouble(2, c.getValorDivida());
            ps.setString(3, c.getNivelInteracao());
            ps.setString(4, c.getCpf());
            return ps.executeUpdate() > 0; // Retorna true se atualizou algum registro
        }
    }

    /**
     * Remove um cliente do banco usando o CPF como identificador.
     * Retorna true se o cliente foi removido com sucesso.
     */
    public boolean removerCliente(String cpf) throws SQLException {
        String sql = "DELETE FROM clientes WHERE cpf = ?";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, cpf);
            return ps.executeUpdate() > 0; // true se removeu algum registro
        }
    }

    /**
     * Pesquisa clientes cujo CPF ou nome contenha o termo informado.
     * Retorna a lista de clientes encontrados.
     */
    public List<Cliente> pesquisarClientes(String termo) throws SQLException {
        String sql = "SELECT * FROM clientes WHERE cpf LIKE ? OR nome_completo LIKE ?";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            String likeTerm = "%" + termo + "%"; // Termo para busca parcial
            ps.setString(1, likeTerm);
            ps.setString(2, likeTerm);
            ResultSet rs = ps.executeQuery();
            List<Cliente> clientes = new ArrayList<>();
            // Adiciona cada cliente encontrado na lista
            while (rs.next()) {
                clientes.add(new Cliente(
                    rs.getString("cpf"),
                    rs.getInt("id_interno"),
                    rs.getString("nome_completo"),
                    rs.getDouble("valor_divida"),
                    rs.getString("nivel_interacao")
                ));
            }
            return clientes;
        }
    }
}

